-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 26, 2019 at 11:23 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobstersgame`
--

-- --------------------------------------------------------

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
CREATE TABLE IF NOT EXISTS `characters` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `belongsto` bigint(255) NOT NULL,
  `characterloaded` int(11) NOT NULL,
  `alert` int(11) NOT NULL DEFAULT '0',
  `admin` int(11) NOT NULL DEFAULT '0',
  `class` int(11) NOT NULL DEFAULT '0',
  `charactername` text NOT NULL,
  `level` bigint(255) NOT NULL DEFAULT '1',
  `experience` bigint(255) NOT NULL DEFAULT '0',
  `max_experience` bigint(255) NOT NULL DEFAULT '20',
  `hired_guns` bigint(20) NOT NULL DEFAULT '0',
  `skill_points` bigint(255) NOT NULL DEFAULT '0',
  `topmob1` text NOT NULL,
  `topmob2` text NOT NULL,
  `topmob3` text NOT NULL,
  `topmob4` text NOT NULL,
  `topmob5` text NOT NULL,
  `topmob6` text NOT NULL,
  `topmob7` text NOT NULL,
  `topmob8` text NOT NULL,
  `energy_sent_1` text NOT NULL,
  `energy_sent_2` text NOT NULL,
  `energy_sent_3` text NOT NULL,
  `energy_sent_4` text NOT NULL,
  `energy_sent_5` text NOT NULL,
  `energy_sent_6` text NOT NULL,
  `energy_sent_7` text NOT NULL,
  `energy_sent_8` text NOT NULL,
  `claimedbonus` text NOT NULL,
  `cash` bigint(255) NOT NULL DEFAULT '10000',
  `bank` bigint(255) NOT NULL DEFAULT '0',
  `income` bigint(255) NOT NULL DEFAULT '0',
  `favor_points` bigint(255) NOT NULL DEFAULT '10000',
  `fights_won` bigint(255) NOT NULL DEFAULT '0',
  `fights_lost` bigint(255) NOT NULL DEFAULT '0',
  `deaths` bigint(255) NOT NULL DEFAULT '0',
  `mobsters_whacked` bigint(255) NOT NULL DEFAULT '0',
  `bountys_collected` bigint(255) NOT NULL DEFAULT '0',
  `missions_completed` bigint(255) NOT NULL DEFAULT '0',
  `stamina` bigint(255) NOT NULL DEFAULT '3',
  `max_stamina` bigint(255) NOT NULL DEFAULT '3',
  `energy` bigint(255) NOT NULL DEFAULT '10',
  `max_energy` bigint(255) NOT NULL DEFAULT '10',
  `health` bigint(255) NOT NULL DEFAULT '100',
  `max_health` bigint(255) NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `characters`
--

INSERT INTO `characters` (`id`, `belongsto`, `characterloaded`, `alert`, `admin`, `class`, `charactername`, `level`, `experience`, `max_experience`, `hired_guns`, `skill_points`, `topmob1`, `topmob2`, `topmob3`, `topmob4`, `topmob5`, `topmob6`, `topmob7`, `topmob8`, `energy_sent_1`, `energy_sent_2`, `energy_sent_3`, `energy_sent_4`, `energy_sent_5`, `energy_sent_6`, `energy_sent_7`, `energy_sent_8`, `claimedbonus`, `cash`, `bank`, `income`, `favor_points`, `fights_won`, `fights_lost`, `deaths`, `mobsters_whacked`, `bountys_collected`, `missions_completed`, `stamina`, `max_stamina`, `energy`, `max_energy`, `health`, `max_health`) VALUES
(9, 1, 0, 0, 0, 2, 'bobby', 1, 0, 20, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 10000, 0, 0, 10000, 0, 0, 0, 0, 0, 0, 3, 3, 10, 10, 100, 100),
(10, 2, 1, 0, 0, 0, 'Killrt', 1, 0, 20, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 10000, 0, 0, 10000, 0, 0, 0, 0, 0, 0, 3, 3, 10, 10, 100, 100),
(11, 1, 1, 0, 0, 0, 'Jack', 1, 0, 20, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 10000, 0, 0, 10000, 0, 0, 0, 0, 0, 0, 3, 3, 10, 10, 100, 100);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
CREATE TABLE IF NOT EXISTS `equipment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `can_sell` int(11) NOT NULL DEFAULT '0',
  `type` text NOT NULL,
  `picture_name` text NOT NULL,
  `name` text NOT NULL,
  `attack` bigint(255) NOT NULL,
  `defense` bigint(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`id`, `can_sell`, `type`, `picture_name`, `name`, `attack`, `defense`) VALUES
(1, 1, 'weapon', 'golf_club.jpg', 'Golf Club', 2, 1),
(2, 1, 'weapon', 'flick_knife.jpg', 'Flick Knife', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `gametimers`
--

DROP TABLE IF EXISTS `gametimers`;
CREATE TABLE IF NOT EXISTS `gametimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `healthtimer` text NOT NULL,
  `energytimer` text NOT NULL,
  `staminatimer` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gametimers`
--

INSERT INTO `gametimers` (`id`, `healthtimer`, `energytimer`, `staminatimer`) VALUES
(1, '2019-06-26 19:18:20', '2019-06-26 19:17:14', '2019-06-26 19:18:00');

-- --------------------------------------------------------

--
-- Table structure for table `hitlist`
--

DROP TABLE IF EXISTS `hitlist`;
CREATE TABLE IF NOT EXISTS `hitlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `character_id` text NOT NULL,
  `bounty` varchar(255) NOT NULL,
  `set_by` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hitlist`
--

INSERT INTO `hitlist` (`id`, `character_id`, `bounty`, `set_by`) VALUES
(1, '3', '10000000', '2');

-- --------------------------------------------------------

--
-- Table structure for table `leveling_up`
--

DROP TABLE IF EXISTS `leveling_up`;
CREATE TABLE IF NOT EXISTS `leveling_up` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` bigint(255) NOT NULL,
  `exp_required` bigint(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leveling_up`
--

INSERT INTO `leveling_up` (`id`, `level`, `exp_required`) VALUES
(1, 1, 20),
(2, 2, 20),
(3, 3, 20),
(4, 4, 20),
(5, 5, 20),
(6, 6, 40),
(7, 7, 40),
(8, 8, 40),
(9, 9, 40),
(10, 10, 100),
(11, 11, 100),
(12, 12, 100),
(13, 13, 100),
(14, 14, 100),
(15, 15, 100),
(16, 16, 100),
(17, 17, 300);

-- --------------------------------------------------------

--
-- Table structure for table `missions`
--

DROP TABLE IF EXISTS `missions`;
CREATE TABLE IF NOT EXISTS `missions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `release` int(11) NOT NULL DEFAULT '0',
  `city_name` text NOT NULL,
  `mission_name` text NOT NULL,
  `mission_quote` text NOT NULL,
  `min_cash` bigint(255) NOT NULL,
  `max_cash` bigint(255) NOT NULL,
  `experience` bigint(255) NOT NULL,
  `energy_needed` bigint(255) NOT NULL,
  `mob_needed` int(11) NOT NULL,
  `loot_chance_min` int(11) NOT NULL DEFAULT '0',
  `loot_chance_max` int(11) NOT NULL DEFAULT '5',
  `howmany_loot` int(11) NOT NULL DEFAULT '1',
  `loot_weapon_id` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `missions`
--

INSERT INTO `missions` (`id`, `release`, `city_name`, `mission_name`, `mission_quote`, `min_cash`, `max_cash`, `experience`, `energy_needed`, `mob_needed`, `loot_chance_min`, `loot_chance_max`, `howmany_loot`, `loot_weapon_id`) VALUES
(1, 0, 'da_bronx', 'Petty Theft', 'Using\' a crummy bike lock like that one, it\'s almost like he\'s darin\' you to steal it.', 40, 175, 3, 2, 1, 0, 5, 1, ''),
(2, 0, 'da_bronx', 'Residential Burglary', 'Stakeout Sammy says his family just loaded up da SUV for a weekend outta town.', 300, 800, 1, 1, 1, 0, 5, 1, '1'),
(3, 0, 'da_bronx', 'Back-Alley Mugging', '', 850, 1200, 2, 3, 1, 0, 5, 1, '2');

-- --------------------------------------------------------

--
-- Table structure for table `mob_members`
--

DROP TABLE IF EXISTS `mob_members`;
CREATE TABLE IF NOT EXISTS `mob_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` text NOT NULL,
  `request_id` text NOT NULL,
  `accepted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `owned_equipment`
--

DROP TABLE IF EXISTS `owned_equipment`;
CREATE TABLE IF NOT EXISTS `owned_equipment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `equipment_id` text NOT NULL,
  `player_id` text NOT NULL,
  `how_many` bigint(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `owned_equipment`
--

INSERT INTO `owned_equipment` (`id`, `equipment_id`, `player_id`, `how_many`) VALUES
(1, '2', '1', 1),
(2, '1', '6', 3),
(3, '2', '8', 1);

-- --------------------------------------------------------

--
-- Table structure for table `registered_users`
--

DROP TABLE IF EXISTS `registered_users`;
CREATE TABLE IF NOT EXISTS `registered_users` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `ip` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registered_users`
--

INSERT INTO `registered_users` (`id`, `ip`, `email`, `password`) VALUES
(1, '71.228.53.52', 'secret.angnet@gmail.com', 'rick14');

-- --------------------------------------------------------

--
-- Table structure for table `virtual_goods`
--

DROP TABLE IF EXISTS `virtual_goods`;
CREATE TABLE IF NOT EXISTS `virtual_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display` int(11) NOT NULL DEFAULT '0',
  `item_name` text NOT NULL,
  `item_number` text NOT NULL,
  `points` bigint(255) NOT NULL,
  `price` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `virtual_goods`
--

INSERT INTO `virtual_goods` (`id`, `display`, `item_name`, `item_number`, `points`, `price`) VALUES
(1, 1, '21 Favor Points', '6516816516562250', 21, '4.99'),
(2, 1, '42 Favor Points', '5196529509650650', 42, '9.99'),
(3, 1, '85 Favor Points', '7551812452620521', 85, '19.99'),
(4, 1, '170 Favor Points', '2155240502752145', 170, '39.99'),
(5, 1, '215 Favor Points', '2572045205242036', 215, '49.99'),
(6, 1, '440 Favor Points', '4205245252452052', 440, '99.99'),
(7, 1, '1000 Favor Points', '5420752535420498', 1000, '199.99');

-- --------------------------------------------------------

--
-- Table structure for table `virtual_payments`
--

DROP TABLE IF EXISTS `virtual_payments`;
CREATE TABLE IF NOT EXISTS `virtual_payments` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `character_id` text NOT NULL,
  `payer_email` text NOT NULL,
  `txnid` varchar(20) NOT NULL,
  `payment_amount` decimal(7,2) NOT NULL,
  `payment_status` varchar(25) NOT NULL,
  `itemid` varchar(25) NOT NULL,
  `createdtime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DELIMITER $$
--
-- Events
--
DROP EVENT `Health Timer`$$
CREATE DEFINER=`ricky`@`%` EVENT `Health Timer` ON SCHEDULE EVERY 3 MINUTE STARTS '2019-06-26 02:27:20' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN

UPDATE characters SET health=health+1 WHERE health<>max_health;

UPDATE gametimers SET healthtimer = (now() + INTERVAL 3 MINUTE);

END$$

DROP EVENT `Stamina Timer`$$
CREATE DEFINER=`ricky`@`%` EVENT `Stamina Timer` ON SCHEDULE EVERY 2 MINUTE STARTS '2019-06-25 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN

UPDATE characters SET stamina=stamina+1 WHERE stamina<>max_stamina;

UPDATE gametimers SET staminatimer = (now() + INTERVAL 2 MINUTE);

END$$

DROP EVENT `Energy Timer`$$
CREATE DEFINER=`ricky`@`%` EVENT `Energy Timer` ON SCHEDULE EVERY 5 MINUTE STARTS '2019-06-25 03:12:14' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN

UPDATE characters SET energy=energy+1 WHERE energy<>max_energy;

UPDATE gametimers SET energytimer = (now() + INTERVAL 5 MINUTE);

END$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
