<?php
//** PREVENT BOTS
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if(!IS_AJAX) {
http_response_code(404);
die();
}

session_start();
if(!$_SESSION['user_id'] == null){
require '../../conn1651651651651.php';
$user_id = $_SESSION['user_id'];
$character_id = $_SESSION['character_id'];
$result = $mysqli->query("SELECT * FROM characters WHERE id='".$character_id."'");
$row = mysqli_fetch_assoc($result);
?>

<body bgcolor='black'>

<span class="hospital_bg">

<b><div style='width:990px;line-height:1.4;border-bottom: 1px solid white;font-size:25px;color:white;'>Hospital</div></b>
<div style='padding:10px 0px 0px 0px;'></div>


</span>
<?php
}
?>