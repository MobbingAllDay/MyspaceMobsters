<b><div style='line-height:1.4;border-bottom: 1px solid white;font-size:25px;color:white;' align='left'>The Hit List</div></b>

<b><font size='3' color='white'>Make a hit on a mobster listed below to collect the bounty put out on them!<br>
Or, If you've got a rival you need taken out, you can add that mobster to the hit list below by clicking "Add To Hit List" on their mobster profile page.
</font></b>