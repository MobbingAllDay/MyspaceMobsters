<body bgcolor='black'>
<?php
//** PREVENT BOTS
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if(!IS_AJAX) {
http_response_code(404);
die();
}

session_start();
if(!$_SESSION['user_id'] == null){
date_default_timezone_set('US/Eastern');
$date_today = date("m/d/Y");
require '../../conn1651651651651.php';
$user_id = $_SESSION['user_id'];
$character_id = $_SESSION['character_id'];
?>
<table style='width:440px;padding-top:20px;color:white;' border='0' align='right'><tr><td>
<b><font size='4.5' color='orange'>TIP: Dust yourself off and try again.</font></b><br>
Want to try again with a different Mobster class? With our
new save/load game feature you can create up to 3 mobster
characters under one Myspace account which will share favor
points and mob members. <a style='color:#0D7BD5;' href="#" onclick='mymobsterstabb();'>Click here</a> to check it out!
</td></tr></table>

<table style='width:500px;padding-left:10px;padding-top:10px;display:block;' border='0'><tr><td>
<div style='font-size:23px;color:orange;'>Your Top Mob <b><font color='#8F1F07'>(new!)</font></b></div>
</td></tr><tr><td>
<?php
$result = $mysqli->query("SELECT * FROM characters WHERE id='".$character_id."'");
$row = mysqli_fetch_assoc($result);

// top mob info
$re_1 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob1']."'");
$w_1 = mysqli_fetch_assoc($re_1);
$belongsto_1 = $w_1['belongsto'];
$image_1 = "images/users/".$belongsto_1.".png";
if(!file_exists($image_1)){
$image_1 = "images/users/user.png";
}

$re_2 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob2']."'");
$w_2 = mysqli_fetch_assoc($re_2);
$belongsto_2 = $w_2['belongsto'];
$image_2 = "images/users/".$belongsto_2.".png";
if(!file_exists($image_2)){
$image_2 = "images/users/user.png";
}

$re_3 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob3']."'");
$w_3 = mysqli_fetch_assoc($re_3);
$belongsto_3 = $w_3['belongsto'];
$image_3 = "images/users/".$belongsto_3.".png";
if(!file_exists($image_3)){
$image_3 = "images/users/user.png";
}

$re_4 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob4']."'");
$w_4 = mysqli_fetch_assoc($re_4);
$belongsto_4 = $w_4['belongsto'];
$image_4 = "images/users/".$belongsto_4.".png";
if(!file_exists($image_4)){
$image_4 = "images/users/user.png";
}

$re_5 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob5']."'");
$w_5 = mysqli_fetch_assoc($re_5);
$belongsto_5 = $w_5['belongsto'];
$image_5 = "images/users/".$belongsto_5.".png";
if(!file_exists($image_5)){
$image_5 = "images/users/user.png";
}

$re_6 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob6']."'");
$w_6 = mysqli_fetch_assoc($re_6);
$belongsto_6 = $w_6['belongsto'];
$image_6 = "images/users/".$belongsto_6.".png";
if(!file_exists($image_6)){
$image_6 = "images/users/user.png";
}

$re_7 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob7']."'");
$w_7 = mysqli_fetch_assoc($re_7);
$belongsto_7 = $w_7['belongsto'];
$image_7 = "images/users/".$belongsto_7.".png";
if(!file_exists($image_7)){
$image_7 = "images/users/user.png";
}

$re_8 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob8']."'");
$w_8 = mysqli_fetch_assoc($re_8);
$belongsto_8 = $w_8['belongsto'];
$image_8 = "images/users/".$belongsto_8.".png";
if(!file_exists($image_8)){
$image_8 = "images/users/user.png";
}

$total_claim = $w_1['income']/16+$w_2['income']/16+$w_3['income']/16+$w_4['income']/16+$w_5['income']/16+$w_6['income']/16+$w_7['income']/16+$w_8['income']/16;
$total_exp = "0";

if($row['topmob1'] !== ''){
$total_exp = $total_exp+1;
}
if($row['topmob2'] !== ''){
$total_exp = $total_exp+1;
}
if($row['topmob3'] !== ''){
$total_exp = $total_exp+1;
}
if($row['topmob4'] !== ''){
$total_exp = $total_exp+1;
}
if($row['topmob5'] !== ''){
$total_exp = $total_exp+1;
}
if($row['topmob6'] !== ''){
$total_exp = $total_exp+1;
}
if($row['topmob7'] !== ''){
$total_exp = $total_exp+1;
}
if($row['topmob8'] !== ''){
$total_exp = $total_exp+1;
}

if($row['topmob1'] == '' && $row['topmob2'] == '' && $row['topmob3'] == '' && $row['topmob4'] == '' && $row['topmob5'] == '' && $row['topmob6'] == '' && $row['topmob7'] == '' && $row['topmob8'] == ''){
?>
<div style='width:100%;padding-left:5px;padding-top:0px;color:white;'>

<table style='color:white;font-size:16px;' align='left' border='0'><tr>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="80" height="80" style="margin-top: 3px; border: 0;" src="images/emptyslot.gif"><br><br><div style="font-size:13px;color:grey;text-align: center;"> This spot<br>available.<br></div></center></div></td>
</tr></table>

<table style='width:350px;color:white;font-size:19px;' align='left' border='0'><tr>
<td>
<b>Want extra cash and experience?</b>
<br><br>
<b>Want a bigger mob in fights?</b>
<br><br>
Promote your most active mob members to
your Top Mob!
</td></tr></table>

</div></td></tr></table>
<?php }else{ ?>
<div style='width:100%;padding-left:5px;padding-top:0px;color:white;'><table style='color:white;font-size:16px;' align='left'><tr><td>
<?php if($row['claimedbonus'] == $date_today){ ?>
You have already claimed your top mob bonus today.
<?php }else{ ?>
Your <b>8</b> <font color='green'>active</font> top mobs have <b><font color="yellow">$<?php echo number_format($total_claim); ?></font></b> + <?php echo $total_exp; ?> exp</td></tr></table> <table style='padding-left:20px;' align='left'><tr><td><button style="background-color:#383889;border: solid 1px grey;color:white;cursor:pointer;padding-top:2px;padding-bottom:2px;padding-left:7px;padding-right:7px;" onclick="claim_bonus();" type="button">Claim it now!</button>
<?php } ?>
</td></tr></table></div>
</td></tr></table>

<table style="padding-left:10px;text-align:left;padding-top:0px;" border='0'><tr>
<?php
if($row['topmob1'] == ''){
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="80" height="80" style="margin-top: 3px; border: 0;" src="images/emptyslot.gif"><br><br><div style="font-size:13px;color:grey;text-align: center;"> This spot<br>available.<br></div></center></div></td>
<?php 
}
if($row['topmob1'] !== ''){
$top_mob_bonus_1 = $w_1['income']/16;
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="95" height="90" style="margin-top: 3px; border: 0;" src="<?php echo $image_1; ?>"><br><div style="font-size:13px;color:yellow;text-align: left;padding-left:5px;"><b>$<?php echo number_format($top_mob_bonus_1); ?></b></div><div style='padding-left:5px;padding-bottom:5px;color:white;font-size:15px;text-align:left;'>+1 exp</div>
<?php if($row['energy_sent_1'] == $date_today){ ?>
<div style='font-size:13;color:white;'>Energy Sent</div>
<?php }else{ ?>
<button style='background-color:#383889;border: solid 1px grey;color:white;cursor:pointer;padding-top:2px;padding-bottom:2px;padding-left:15px;padding-right:15px;' onclick="var id = '<?php echo $row['topmob1']; ?>'; send_energy(id);" type="button">Send Energy</button><br>
<?php } ?>
</center></div></td>
<?php } ?>

<?php
if($row['topmob2'] == ''){
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="80" height="80" style="margin-top: 3px; border: 0;" src="images/emptyslot.gif"><br><br><div style="font-size:13px;color:grey;text-align: center;"> This spot<br>available.<br></div></center></div></td>
<?php 
}
if($row['topmob2'] !== ''){
$top_mob_bonus_2 = $w_2['income']/16;
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="95" height="90" style="margin-top: 3px; border: 0;" src="<?php echo $image_2; ?>"><br><div style="font-size:13px;color:yellow;text-align: left;padding-left:5px;"><b>$<?php echo number_format($top_mob_bonus_2); ?></b></div><div style='padding-left:5px;padding-bottom:5px;color:white;font-size:15px;text-align:left;'>+1 exp</div>
<?php if($row['energy_sent_2'] == $date_today){ ?>
<div style='font-size:13;color:white;'>Energy Sent</div>
<?php }else{ ?>
<button style='background-color:#383889;border: solid 1px grey;color:white;cursor:pointer;padding-top:2px;padding-bottom:2px;padding-left:15px;padding-right:15px;' onclick="var id = '<?php echo $row['topmob2']; ?>'; send_energy(id);" type="button">Send Energy</button><br>
<?php } ?>
</center></div></td>
<?php } ?>

<?php
if($row['topmob3'] == ''){
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="80" height="80" style="margin-top: 3px; border: 0;" src="images/emptyslot.gif"><br><br><div style="font-size:13px;color:grey;text-align: center;"> This spot<br>available.<br></div></center></div></td>
<?php 
}
if($row['topmob3'] !== ''){
$top_mob_bonus_3 = $w_3['income']/16;
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="95" height="90" style="margin-top: 3px; border: 0;" src="<?php echo $image_3; ?>"><br><div style="font-size:13px;color:yellow;text-align: left;padding-left:5px;"><b>$<?php echo number_format($top_mob_bonus_3); ?></b></div><div style='padding-left:5px;padding-bottom:5px;color:white;font-size:15px;text-align:left;'>+1 exp</div>
<?php if($row['energy_sent_3'] == $date_today){ ?>
<div style='font-size:13;color:white;'>Energy Sent</div>
<?php }else{ ?>
<button style='background-color:#383889;border: solid 1px grey;color:white;cursor:pointer;padding-top:2px;padding-bottom:2px;padding-left:15px;padding-right:15px;' onclick="var id = '<?php echo $row['topmob3']; ?>'; send_energy(id);" type="button">Send Energy</button><br>
<?php } ?>
</center></div></td>
<?php } ?>

<?php
if($row['topmob4'] == ''){
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="80" height="80" style="margin-top: 3px; border: 0;" src="images/emptyslot.gif"><br><br><div style="font-size:13px;color:grey;text-align: center;"> This spot<br>available.<br></div></center></div></td>
<?php 
}
if($row['topmob4'] !== ''){
$top_mob_bonus_4 = $w_4['income']/16;
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="95" height="90" style="margin-top: 3px; border: 0;" src="<?php echo $image_4; ?>"><br><div style="font-size:13px;color:yellow;text-align: left;padding-left:5px;"><b>$<?php echo number_format($top_mob_bonus_4); ?></b></div><div style='padding-left:5px;padding-bottom:5px;color:white;font-size:15px;text-align:left;'>+1 exp</div>
<?php if($row['energy_sent_4'] == $date_today){ ?>
<div style='font-size:13;color:white;'>Energy Sent</div>
<?php }else{ ?>
<button style='background-color:#383889;border: solid 1px grey;color:white;cursor:pointer;padding-top:2px;padding-bottom:2px;padding-left:15px;padding-right:15px;' onclick="var id = '<?php echo $row['topmob4']; ?>'; send_energy(id);" type="button">Send Energy</button><br>
<?php } ?>
</center></div></td>
<?php } ?>


</tr><tr>

<?php
if($row['topmob5'] == ''){
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="80" height="80" style="margin-top: 3px; border: 0;" src="images/emptyslot.gif"><br><br><div style="font-size:13px;color:grey;text-align: center;"> This spot<br>available.<br></div></center></div></td>
<?php 
}
if($row['topmob5'] !== ''){
$top_mob_bonus_5 = $w_5['income']/16;
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="95" height="90" style="margin-top: 3px; border: 0;" src="<?php echo $image_5; ?>"><br><div style="font-size:13px;color:yellow;text-align: left;padding-left:5px;"><b>$<?php echo number_format($top_mob_bonus_5); ?></b></div><div style='padding-left:5px;padding-bottom:5px;color:white;font-size:15px;text-align:left;'>+1 exp</div>
<?php if($row['energy_sent_5'] == $date_today){ ?>
<div style='font-size:13;color:white;'>Energy Sent</div>
<?php }else{ ?>
<button style='background-color:#383889;border: solid 1px grey;color:white;cursor:pointer;padding-top:2px;padding-bottom:2px;padding-left:15px;padding-right:15px;' onclick="var id = '<?php echo $row['topmob5']; ?>'; send_energy(id);" type="button">Send Energy</button><br>
<?php } ?>
</center></div></td>
<?php } ?>

<?php
if($row['topmob6'] == ''){
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="80" height="80" style="margin-top: 3px; border: 0;" src="images/emptyslot.gif"><br><br><div style="font-size:13px;color:grey;text-align: center;"> This spot<br>available.<br></div></center></div></td>
<?php 
}
if($row['topmob6'] !== ''){
$top_mob_bonus_6 = $w_6['income']/16;
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="95" height="90" style="margin-top: 3px; border: 0;" src="<?php echo $image_6; ?>"><br><div style="font-size:13px;color:yellow;text-align: left;padding-left:5px;"><b>$<?php echo number_format($top_mob_bonus_6); ?></b></div><div style='padding-left:5px;padding-bottom:5px;color:white;font-size:15px;text-align:left;'>+1 exp</div>
<?php if($row['energy_sent_6'] == $date_today){ ?>
<div style='font-size:13;color:white;'>Energy Sent</div>
<?php }else{ ?>
<button style='background-color:#383889;border: solid 1px grey;color:white;cursor:pointer;padding-top:2px;padding-bottom:2px;padding-left:15px;padding-right:15px;' onclick="var id = '<?php echo $row['topmob6']; ?>'; send_energy(id);" type="button">Send Energy</button><br>
<?php } ?>
</center></div></td>
<?php } ?>

<?php
if($row['topmob7'] == ''){
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="80" height="80" style="margin-top: 3px; border: 0;" src="images/emptyslot.gif"><br><br><div style="font-size:13px;color:grey;text-align: center;"> This spot<br>available.<br></div></center></div></td>
<?php 
}
if($row['topmob7'] !== ''){
$top_mob_bonus_7 = $w_7['income']/16;
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="95" height="90" style="margin-top: 3px; border: 0;" src="<?php echo $image_7; ?>"><br><div style="font-size:13px;color:yellow;text-align: left;padding-left:5px;"><b>$<?php echo number_format($top_mob_bonus_7); ?></b></div><div style='padding-left:5px;padding-bottom:5px;color:white;font-size:15px;text-align:left;'>+1 exp</div>
<?php if($row['energy_sent_7'] == $date_today){ ?>
<div style='font-size:13;color:white;'>Energy Sent</div>
<?php }else{ ?>
<button style='background-color:#383889;border: solid 1px grey;color:white;cursor:pointer;padding-top:2px;padding-bottom:2px;padding-left:15px;padding-right:15px;' onclick="var id = '<?php echo $row['topmob7']; ?>'; send_energy(id);" type="button">Send Energy</button><br>
<?php } ?>
</center></div></td>
<?php } ?>

<?php
if($row['topmob8'] == ''){
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="80" height="80" style="margin-top: 3px; border: 0;" src="images/emptyslot.gif"><br><br><div style="font-size:13px;color:grey;text-align: center;"> This spot<br>available.<br></div></center></div></td>
<?php 
}
if($row['topmob8'] !== ''){
$top_mob_bonus_8 = $w_8['income']/16;
?>
<td><div style="background-image: url('images/gb1.png');background-size: 100% 100%;background-repeat: no-repeat;background-attachment: scroll;display:inline-block;height:158px;width:130px;border: 2px solid #0B6C4A;"><center><img width="95" height="90" style="margin-top: 3px; border: 0;" src="<?php echo $image_8; ?>"><br><div style="font-size:13px;color:yellow;text-align: left;padding-left:5px;"><b>$<?php echo number_format($top_mob_bonus_8); ?></b></div><div style='padding-left:5px;padding-bottom:5px;color:white;font-size:15px;text-align:left;'>+1 exp</div>
<?php if($row['energy_sent_8'] == $date_today){ ?>
<div style='font-size:13;color:white;'>Energy Sent</div>
<?php }else{ ?>
<button style='background-color:#383889;border: solid 1px grey;color:white;cursor:pointer;padding-top:2px;padding-bottom:2px;padding-left:15px;padding-right:15px;' onclick="var id = '<?php echo $row['topmob8']; ?>'; send_energy(id);" type="button">Send Energy</button><br>
<?php } ?>
</center></div></td>
<?php } ?>

</td></tr></table>

<?php
}
}
?>