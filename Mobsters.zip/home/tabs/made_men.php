<?php
//** PREVENT BOTS
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if(!IS_AJAX) {
http_response_code(404);
die();
}

require '../../conn1651651651651.php';
?>
<div style='padding:40px 0px 0px 0px;'></div>
<table align='center'><tr><td>
<?php
$query = $mysqli->query("SELECT * FROM `characters` ORDER BY fights_won LIMIT 0,10") or die('Invalid query: ' . mysql_error());
echo "<table style='color:white;' align='left'><tr style='background-color:#44150B;'><td style='width:300;'>Top Fighters</td><td style='width:300;'>Wins</td></tr>";
while($fetch = mysqli_fetch_assoc($query)){
echo "<tr><td>".$fetch['charactername']."</td><td>".number_format($fetch['fights_won'])."</td></tr>";
}
echo "</table>";
?>
</td><td>
<?php
$query = $mysqli->query("SELECT * FROM `characters` ORDER BY fights_lost LIMIT 0,10") or die('Invalid query: ' . mysql_error());
echo "<table style='color:white;' align='left'><tr style='background-color:#44150B;'><td style='width:300;'>Top Losers</td><td style='width:300;'>Loses</td></tr>";
while($fetch = mysqli_fetch_assoc($query)){
echo "<tr><td>".$fetch['charactername']."</td><td>".number_format($fetch['fights_lost'])."</td></tr>";
}
echo "</table>";
?>
</td></tr></table>





<table align='center'><tr><td>
<?php
$query = $mysqli->query("SELECT * FROM `characters` ORDER BY mobsters_whacked LIMIT 0,10") or die('Invalid query: ' . mysql_error());
echo "<table style='color:white;' align='left'><tr style='background-color:#44150B;'><td style='width:300;'>Deadliest Foes</td><td style='width:300;'>Whacks</td></tr>";
while($fetch = mysqli_fetch_assoc($query)){
echo "<tr><td>".$fetch['charactername']."</td><td>".number_format($fetch['mobsters_whacked'])."</td></tr>";
}
echo "</table>";
?>
</td><td>
<?php
$query = $mysqli->query("SELECT * FROM `characters` ORDER BY bountys_collected LIMIT 0,10") or die('Invalid query: ' . mysql_error());
echo "<table style='color:white;' align='left'><tr style='background-color:#44150B;'><td style='width:300;'>Top Hitmen</td><td style='width:300;'>Body Count</td></tr>";
while($fetch = mysqli_fetch_assoc($query)){
echo "<tr><td>".$fetch['charactername']."</td><td>".number_format($fetch['bountys_collected'])."</td></tr>";
}
echo "</table>";
?>
</td></tr></table>