<?php
/*
//** PREVENT BOTS
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if(!IS_AJAX) {
http_response_code(404);
die();
}
*/

require '../../conn1651651651651.php';
session_start();
if(!$_SESSION['user_id'] == null){
$user_id = $_SESSION['user_id'];
$character_id = $_SESSION['character_id'];
$result = $mysqli->query("SELECT * FROM characters WHERE id='".$character_id."' AND belongsto='".$user_id."'");
$row = mysqli_fetch_assoc($result);
$count = mysqli_num_rows($result);
if($count == 0){
$_SESSION['character_id'] = "";
echo "<script>top.window.location = '../home/'</script>";
exit;
}

// game timers
$rwt = $mysqli->query("SELECT * FROM gametimers");
$ryw = mysqli_fetch_assoc($rwt);

$health = $row['health'];
$max_health = $row['max_health'];
if($health == '0'){
$percent_health = $health/$max_health;
$total_health = number_format($percent_health * 100, 2 ). '%';
}
if($health > '0'){
$percent_health = $health/$max_health;
$total_health = number_format($percent_health * 100-1, 2 ). '%';
}

$energy = $row['energy'];
$max_energy = $row['max_energy'];
if($energy == '0'){
$percent_energy = $energy/$max_energy;
$total_energy = number_format($percent_energy * 100, 2 ). '%';
}

if($energy > '0'){
if($energy < '11'){
$percent_energy = $energy/$max_energy;
$total_energy = number_format($percent_energy * 100-1, 2 ). '%';
}
if($energy > '10'){
$total_energy = '99%';
}
}

$stamina = $row['stamina'];
$max_stamina = $row['max_stamina'];
if($stamina == '0'){
$percent_stamina = $stamina/$max_stamina;
$total_stamina = number_format($percent_stamina * 100, 2 ). '%';
}
if($stamina > '0'){
$percent_stamina = $stamina/$max_stamina;
$total_stamina = number_format($percent_stamina * 100-1, 2 ). '%';
}

function abreviateTotalCount($value) {
$abbreviations = array(18 => 'q', 15 => 'Q', 12 => 'T', 9 => 'B', 6 => 'M', 3 => 'K', 0 => '');
foreach($abbreviations as $exponent => $abbreviation) 
{
if($value >= pow(10, $exponent)) 
{
return round(floatval($value / pow(10, $exponent)),1).$abbreviation;
}
}
}
if($row['cash'] == '0'){
$cash = "$0";
}
if($row['cash'] > '0'){
$cash = "$".abreviateTotalCount($row['cash']);
}
if($row['income'] == '0'){
$income = "$0";
}
if($row['income'] > '0'){
$income = "$".abreviateTotalCount($row['income']);
}

$name = $row['charactername'];

$experience = $row['experience'];
$max_experience = $row['max_experience'];

if($experience > $max_experience){
$total = '100%';
}else{
$percent = $experience/$max_experience;
$total = number_format( $percent * 100, 2 ) . '%';
}

$name = strlen($name) > 11 ? substr($name,0,11)."..." : $name;
?>


<div style="float:right;width:160px;margin-top:10px;margin-right:0px;">
<div style="vertical-align:top;">
<div class="statCell" style="font-size:15px;color:orange;width:100%;max-width:160px;overflow-x:hidden;padding:0px 0px 5px 0px;" id="name"><b><?php echo $name; ?></b> <a onclick='my_stats();' style='cursor:pointer;text-decoration: underline;color:#BEB9D0;'>(stats)</a></div>
<div class="statCell" style="font-size:15px;color:#17B117;width:100%;max-width:100px;overflow-x:hidden;" id="levelstat"><b>Level:<?php echo $row['level']; ?></b></div>
<div class="statCell" style="font-size:15px;width:100%;max-width:150px;overflow-x:hidden;padding:0px 0px 5px 0px;" id="mobstat"><div style="background-color:#6C6F6C;width:70%;border: 1px solid;border-radius:2px;"><div style="background-color:#17B117;height:4px;width:<?php echo $total; ?>"></div></div></div>
<?php
$check_invites = $mysqli->query("SELECT * FROM mob_members WHERE from_id='".$character_id."' AND accepted='1'") or die ('ERROR: ' .mysqli_error());
$mobbies = mysqli_num_rows($check_invites);
$topcount = "0";

if(!$row['topmob1'] == ''){
$topcount = $topcount+1;
$mobbies = $mobbies+1;
}
if(!$row['topmob2'] == ''){
$topcount = $topcount+1;
$mobbies = $mobbies+1;
}
if(!$row['topmob3'] == ''){
$topcount = $topcount+1;
$mobbies = $mobbies+1;
}
if(!$row['topmob4'] == ''){
$topcount = $topcount+1;
$mobbies = $mobbies+1;
}
if(!$row['topmob5'] == ''){
$topcount = $topcount+1;
$mobbies = $mobbies+1;
}
if(!$row['topmob6'] == ''){
$topcount = $topcount+1;
$mobbies = $mobbies+1;
}
if(!$row['topmob7'] == ''){
$topcount = $topcount+1;
$mobbies = $mobbies+1;
}
if(!$row['topmob8'] == ''){
$topcount = $topcount+1;
$mobbies = $mobbies+1;
}

$total_mobsize = 1+$mobbies+$row['hired_guns'];
?>
<div class="statCell" style="font-size:14px;color:white;width:100%;max-width:150px;overflow-x:hidden;padding:0px 0px 0px 0px;" id="hgsstat">Mob size: <?php echo $total_mobsize; ?><font size='2' color="orange"><b> +<?php echo $topcount; ?></b></font></div>			
</div>
<div style="float:right;width:160px;margin-top:20px;margin-right:0px;"><input id='refresh_button' onclick="refresh()" type="button" value='REFRESH'></div>
</div>

<?php

$time_from_db3 = $ryw['healthtimer'];
if($time_from_db3 == ''){
}else{
if($health == $max_health){
}else{
?>
<script>
// Set the date we're counting down to
    var datefromdb3 = "<?php echo $time_from_db3; ?>";
    var countDownDate3 = new Date(datefromdb3).getTime();
    // Update the count down every 1 second
    var x3 = setInterval(function rx3() 
    {

      // Get todays date and time
      var now3 = new Date().getTime();

      // Find the distance between now an the count down date
      var distance3 = (countDownDate3) - (now3);
	  
      //Hint on converting from object to the string.
      //var distance3 = Date.parse(countDownDate3) - Date.parse(now);

      // Time calculations for days, hours, minutes and seconds
      var days3 = Math.floor(distance3 / (1000 * 60 * 60 * 24));
      var hours3 = Math.floor((distance3 % (1000 * 60 * 60 * 24)) / (1000 * 60 * 
      60));
      var minutes3 = Math.floor((distance3 % (1000 * 60 * 60)) / (1000 * 60));
      var seconds3 = Math.floor((distance3 % (1000 * 60)) / 1000);
      if(seconds3 < '10'){
	  var seconds3 = "0" + seconds3;
	  }
	  
	  // If the count down is finished, write some text 
      if (distance3 < 0){
	  var xx3 = document.getElementById("healthtimer").innerHTML = "";
	  timerrefresh();
      } else {
	  // Display the result in the element with id="demo"
      var xx3 = document.getElementById("healthtimer").innerHTML = minutes3 + ":" + seconds3 + " for more";
	  }
	  
      }, 1000);
</script>
<?php } } ?>

<?php
$time_from_db = $ryw['energytimer'];
if($time_from_db == ''){
}else{
if($energy == $max_energy){
}else{
?>
<script> 
// Set the date we're counting down to
    var datefromdb = "<?php echo $time_from_db; ?>";
    var countDownDate = new Date(datefromdb).getTime();
    // Update the count down every 1 second
    var x = setInterval(function rx() 
    {

      // Get todays date and time
      var now = new Date().getTime();

      // Find the distance between now an the count down date
      var distance = (countDownDate) - (now);
	  
      //Hint on converting from object to the string.
      //var distance = Date.parse(countDownDate) - Date.parse(now);

      // Time calculations for days, hours, minutes and seconds
      var days = Math.floor(distance / (1000 * 60 * 60 * 24));
      var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 
      60));
      var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      var seconds = Math.floor((distance % (1000 * 60)) / 1000);  
      if(seconds < '10'){
	  var seconds = "0" + seconds;
	  }
	  
	  // If the count down is finished, write some text 
      if (distance < 0){
	  var xx = document.getElementById("energytimer").innerHTML = "";
	  timerrefresh();
      } else {
	  // Display the result in the element with id="demo"
      var xx = document.getElementById("energytimer").innerHTML = minutes + ":" + seconds + " for more";
	  }
	  
      }, 1000);
</script>
<?php
}
}

?>

<?php
$time_from_db2 = $ryw['staminatimer'];
if($time_from_db2 == ''){
}else{
if($stamina == $max_stamina){
}else{
?>
<script>
// Set the date we're counting down to
    var datefromdb2 = "<?php echo $time_from_db2; ?>";
    var countDownDate2 = new Date(datefromdb2).getTime();
    // Update the count down every 1 second
    var x2 = setInterval(function rx2() 
    {

      // Get todays date and time
      var now2 = new Date().getTime();

      // Find the distance between now an the count down date
      var distance2 = (countDownDate2) - (now2);

      //Hint on converting from object to the string.
      //var distance2 = Date.parse(countDownDate2) - Date.parse(now);

      // Time calculations for days, hours, minutes and seconds
      var days2 = Math.floor(distance2 / (1000 * 60 * 60 * 24));
      var hours2 = Math.floor((distance2 % (1000 * 60 * 60 * 24)) / (1000 * 60 * 
      60));
      var minutes2 = Math.floor((distance2 % (1000 * 60 * 60)) / (1000 * 60));
      var seconds2 = Math.floor((distance2 % (1000 * 60)) / 1000);
      if(seconds2 < '10'){
	  var seconds2 = "0" + seconds2;
	  }

	  // If the count down is finished, write some text 
      if (distance2 < 0){
	  var xx2 = document.getElementById("staminatimer").innerHTML = "";
	  timerrefresh();
      } else {
	  // Display the result in the element with id="demo"
      var xx2 = document.getElementById("staminatimer").innerHTML = minutes2 + ":" + seconds2 + " for more";
	  }
      }, 1000);
</script>
<?php } } ?>


<div style='width:820px;background: hsla(5,5%,5%,0.7);height:28px;position:relative;top:95;left:6%;'>

<div class="statCellNew" style="margin-top: 5px; padding: 0px;position: relative; color:white;width:100%;max-width: 90px;display:inline-block; text-align:left;font-size:15px;">Cash:<span style='font-size:14px;color:yellow;' class="incomeTitleText"><?php echo $cash; ?></span></div>
<div class="statCellNew" style="margin-top: 5px; padding: 0px;position: relative; color:white;width:100%; max-width: 130px;display:inline-block;text-align:left;font-size:15px;">Cash Flow:<span style='font-size:14px;' id="myIncomee"><?php echo $income; ?></span></div>
<div class="statCellNew" style="width:100%;max-width: 181px; display:inline-block;text-align:left;margin:0px; padding: 0px;">
<div id="healthStatus" class="statCell" style="position: relative; left: 0px; top: 0px;">
<div style="position: absolute; left: 0px; top: -14px;">
<ul style="margin: 0px; padding: 0px; list-style-type: none;">
<li style="margin: 0px; float: left; padding: 1px;">
<img style="margin: 0px; width: 16px; height: 16px;" src="../../home/images/s_health.gif">
</li>
<li style="margin: 0px; padding: 0px; float: left; position: relative; width: 112px; height: 16px; background-color: black; border: 1px solid rgb(136, 0, 0);">
<div style="margin: 0px; padding: 0px; width:<?php echo $total_health; ?>; height: 14px; background-color: rgb(136, 0, 0); border: 1px solid black;"></div>

<div style="font-size:15px;margin: 0px; float: left; position: absolute; left: 5px; top: 0px; height: 14px; color: rgb(170, 170, 170);">Health <span class="statsBarReloadTimer" style="width:100px;float:left;position: absolute;top: -20px;left:8px;"><span id="healthtimer"></span></span></div></li>
<li style="margin: 0px; float: left; padding: 0px;overflow-y:hidden;overflow-x:hidden;">
<div style="font-size:15px;color:white;margin-left: 3px; width: 100%; height: 16px;"><?php echo number_format($health); ?></div></li>
</ul></div>
<div class="" style="display:none;"></div>
</div>
</div>

<div class="statCellNew" style="width:100%;max-width: <?php if($energy < '999999'){ echo "191px;"; } if($energy >= '999999'){ echo "205px;"; } if($energy <= '100000'){ echo "191px;"; } ?>display:inline-block;text-align:left;margin: 0px; padding: 0px;">
<div id="energyStatus" class="statCell" style="position: relative; left: 0px; top: 0px;">
<div style="position: absolute; left: 0px; top: -14px;">
<ul style="margin: 0px; padding: 0px; list-style-type: none;">
<li style="margin: 0px; float: left; padding: 1px;">
<img style="margin: 0px; width: 16px; height: 16px;" src="../../home/images/s_energy.gif"></li>
<li style="margin: 0px; padding: 0px; float: left; position: relative; width: 112px; height: 16px; background-color: black; border: 1px solid rgb(136, 0, 0);">
<div style="margin: 0px; padding: 0px; width: <?php echo $total_energy; ?>; height: 14px; background-color: rgb(136, 0, 0); border: 1px solid black;"></div>

<div style="font-size:15px;color:white;margin: 0px; float: left; position: absolute; left: 5px; top: 0px; height: 14px; color: rgb(170, 170, 170);">Energy<span class="statsBarReloadTimer" style="width:100px;float:left;position: absolute;top: -20px;left:8px;"><span id="energytimer"></span></span></div>

</li>
<li style="margin: 0px; float: left; padding: 0px;overflow-y:hidden;overflow-x:hidden;">
<div style="font-size:15px;color:white;margin-left: 3px; width: 100%; height: 16px;"><?php echo number_format($energy); ?></div>
</li>
</ul></div><div class="" style="display:none;"></div>
</div>
</div>
<div class="statCellNew" style="width:100%;max-width: 190px; display:inline-block;text-align:left;margin: 0px; padding: 0px;">
<div id="staminaStatus" class="statCell" style="position: relative; left: 0px; top: 0px;">
<div style="position: absolute; left: 0px; top: -14px;"><ul style="margin: 0px; padding: 0px; list-style-type: none;">
<li style="margin: 0px; float: left; padding: 0px;">
<img style="margin: 0px; width: 16px; height: 16px;" src="../../home/images/s_stamina.gif"></li>
<li style="margin: 0px; padding: 0px; float: left; position: relative; width: 112px; height: 16px; background-color: black; border: 1px solid rgb(136, 0, 0);">
<div style="margin: 0px; padding: 0px; width: <?php echo $total_stamina; ?>; height: 14px; background-color: rgb(136, 0, 0); border: 1px solid black;"></div>

<div style="font-size:15px;color:white;margin: 0px; float: left; position: absolute; left: 5px; top: 0px; height: 14px; color: rgb(170, 170, 170);">Stamina<span class="statsBarReloadTimer" style="width:100px;float:left;position: absolute;top: -20px;left:8px;"><span id="staminatimer"></span></span></div>
</li>
<li style="margin: 0px; float: left; padding: 0px;overflow-y:hidden;overflow-x:hidden;">
<div style="font-size:15px;color:white;margin-left: 3px; width: 100%; height: 16px;"><?php echo number_format($stamina); ?></div>
</li>
</ul></div>
<div class="" style="display:none;"></div></div>
</div>
</div>

<?php
}
?>