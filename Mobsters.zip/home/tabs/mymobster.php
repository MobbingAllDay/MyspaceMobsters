<?php
//** PREVENT BOTS
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if(!IS_AJAX) {
http_response_code(404);
die();
}

require '../../conn1651651651651.php';
session_start();
if(!$_SESSION['user_id'] == null){
$user_id = $_SESSION['user_id'];
$character_id = $_SESSION['character_id'];
$result = $mysqli->query("SELECT * FROM characters WHERE id='".$character_id."'");
$row = mysqli_fetch_assoc($result);

$experience = $row['experience'];
$max_experience = $row['max_experience'];

$left_to_gain = $max_experience-$experience;
?>
<b><div style='line-height:1.4;border-bottom: 1px solid white;font-size:20px;color:grey;' align='left'>
<font color='white'>Your Mobster</font>
<font size='2' color='white'>Stats</font>
</div></b>

<div style='padding:25px 0px 0px 0px;font-size:20px;color:grey;' align='center'>
<font color='white'>You need <b><?php echo $left_to_gain; ?></b> more experience points to gain another level.</font>
</div>


<table style='background-color:#44150B;color:white;'>
<tr>
<td>hrtevhvbvjrujyj</td>
</tr>
</table>

























<?php
}
?>