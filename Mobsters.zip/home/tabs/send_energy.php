<?php
//** PREVENT BOTS
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if(!IS_AJAX) {
http_response_code(404);
die();
}

session_start();
if(!$_SESSION['user_id'] == null){
$character_id = $_SESSION['character_id'];
if(isset($_GET['id'])){
date_default_timezone_set('US/Eastern');
$date_today = date("m/d/Y");
require '../../conn1651651651651.php';
$send_energy_to = trim($_GET['id']);
$result = $mysqli->query("SELECT * FROM characters WHERE id='".$character_id."'");
$row = mysqli_fetch_assoc($result);

$result2 = $mysqli->query("SELECT * FROM characters WHERE id='".$send_energy_to."'");
$count = mysqli_num_rows($result2);
$row2 = mysqli_fetch_assoc($result2);

//find where they are topmobbed.
if($count > 0){
if($row['topmob1'] == $send_energy_to){
if($row['energy_sent_1'] == $date_today){
?>
{
"status": "Insuccesso:",
"message": "You have already sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}else{
$result_4196 = $mysqli->query("UPDATE characters SET energy_sent_1='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET energy=energy+'10' WHERE id='".$send_energy_to."'") or die(mysqli_error("Error.."));
?>
{
"status": "Eccellente!",
"message": "You have sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}
}
}

if($count > 0){
if($row['topmob2'] == $send_energy_to){
if($row['energy_sent_2'] == $date_today){
?>
{
"status": "Insuccesso:",
"message": "You have already sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}else{
$result_4196 = $mysqli->query("UPDATE characters SET energy_sent_2='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET energy=energy+'10' WHERE id='".$send_energy_to."'") or die(mysqli_error("Error.."));
?>
{
"status": "Eccellente!",
"message": "You have sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}
}
}

if($count > 0){
if($row['topmob3'] == $send_energy_to){
if($row['energy_sent_3'] == $date_today){
?>
{
"status": "Insuccesso:",
"message": "You have already sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}else{
$result_4196 = $mysqli->query("UPDATE characters SET energy_sent_3='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET energy=energy+'10' WHERE id='".$send_energy_to."'") or die(mysqli_error("Error.."));
?>
{
"status": "Eccellente!",
"message": "You have sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}
}
}

if($count > 0){
if($row['topmob4'] == $send_energy_to){
if($row['energy_sent_4'] == $date_today){
?>
{
"status": "Insuccesso:",
"message": "You have already sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}else{
$result_4196 = $mysqli->query("UPDATE characters SET energy_sent_4='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET energy=energy+'10' WHERE id='".$send_energy_to."'") or die(mysqli_error("Error.."));
?>
{
"status": "Eccellente!",
"message": "You have sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}
}
}

if($count > 0){
if($row['topmob5'] == $send_energy_to){
if($row['energy_sent_5'] == $date_today){
?>
{
"status": "Insuccesso:",
"message": "You have already sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}else{
$result_4196 = $mysqli->query("UPDATE characters SET energy_sent_5='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET energy=energy+'10' WHERE id='".$send_energy_to."'") or die(mysqli_error("Error.."));
?>
{
"status": "Eccellente!",
"message": "You have sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}
}
}

if($count > 0){
if($row['topmob6'] == $send_energy_to){
if($row['energy_sent_6'] == $date_today){
?>
{
"status": "Insuccesso:",
"message": "You have already sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}else{
$result_4196 = $mysqli->query("UPDATE characters SET energy_sent_6='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET energy=energy+'10' WHERE id='".$send_energy_to."'") or die(mysqli_error("Error.."));
?>
{
"status": "Eccellente!",
"message": "You have sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}
}
}

if($count > 0){
if($row['topmob7'] == $send_energy_to){
if($row['energy_sent_7'] == $date_today){
?>
{
"status": "Insuccesso:",
"message": "You have already sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}else{
$result_4196 = $mysqli->query("UPDATE characters SET energy_sent_7='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET energy=energy+'10' WHERE id='".$send_energy_to."'") or die(mysqli_error("Error.."));
?>
{
"status": "Eccellente!",
"message": "You have sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}
}
}

if($count > 0){
if($row['topmob8'] == $send_energy_to){
if($row['energy_sent_8'] == $date_today){
?>
{
"status": "Insuccesso:",
"message": "You have already sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}else{
$result_4196 = $mysqli->query("UPDATE characters SET energy_sent_8='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET energy=energy+'10' WHERE id='".$send_energy_to."'") or die(mysqli_error("Error.."));
?>
{
"status": "Eccellente!",
"message": "You have sent energy to <?php echo $row2['charactername']; ?>."
}
<?php
}
}
}
//find where they are topmobbed.

}
}
?>