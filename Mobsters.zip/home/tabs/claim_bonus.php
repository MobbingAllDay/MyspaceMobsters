<?php
//** PREVENT BOTS
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if(!IS_AJAX) {
http_response_code(404);
die();
}

session_start();
if(!$_SESSION['user_id'] == null){
date_default_timezone_set('US/Eastern');
$date_today = date("m/d/Y");
require '../../conn1651651651651.php';
$character_id = $_SESSION['character_id'];
$result = $mysqli->query("SELECT * FROM characters WHERE id='".$character_id."'");
$row = mysqli_fetch_assoc($result);

if($row['claimedbonus'] == $date_today){
?>
{
"status": "Insuccesso:",
"message": "You have already claimed your bonus today."
}
<?php
}elseif($row['topmob1'] == '' || $row['topmob2'] == '' || $row['topmob3'] == '' || $row['topmob4'] == '' || $row['topmob5'] == '' || $row['topmob6'] == '' || $row['topmob7'] == '' || $row['topmob8'] == ''){
?>
{
"status": "Insuccesso:",
"message": "There are no members in your top mob!"
}
<?php
}else{
$total_exp_claim = "0";

// top mob info
$re_1 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob1']."'");
$w_1 = mysqli_fetch_assoc($re_1);
$income_1 = $w_1['income'];
if($income_1 == ''){
}else{
$total_exp_claim = $total_exp_claim+1;
}

$re_2 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob2']."'");
$w_2 = mysqli_fetch_assoc($re_2);
$income_2 = $w_2['income'];
if($income_2 == ''){
}else{
$total_exp_claim = $total_exp_claim+1;
}

$re_3 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob3']."'");
$w_3 = mysqli_fetch_assoc($re_3);
$income_3 = $w_3['income'];
if($income_3 == ''){
}else{
$total_exp_claim = $total_exp_claim+1;
}

$re_4 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob4']."'");
$w_4 = mysqli_fetch_assoc($re_4);
$income_4 = $w_4['income'];
if($income_4 == ''){
}else{
$total_exp_claim = $total_exp_claim+1;
}

$re_5 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob5']."'");
$w_5 = mysqli_fetch_assoc($re_5);
$income_5 = $w_5['income'];
if($income_5 == ''){
}else{
$total_exp_claim = $total_exp_claim+1;
}

$re_6 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob6']."'");
$w_6 = mysqli_fetch_assoc($re_6);
$income_6 = $w_6['income'];
if($income_6 == ''){
}else{
$total_exp_claim = $total_exp_claim+1;
}

$re_7 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob7']."'");
$w_7 = mysqli_fetch_assoc($re_7);
$income_7 = $w_7['income'];
if($income_7 == ''){
}else{
$total_exp_claim = $total_exp_claim+1;
}

$re_8 = $mysqli->query("SELECT * FROM characters WHERE id='".$row['topmob8']."'");
$w_8 = mysqli_fetch_assoc($re_8);
$income_8 = $w_8['income'];
if($income_8 == ''){
}else{
$total_exp_claim = $total_exp_claim+1;
}

$total_cash_claim = $income_1/16+$income_2/16+$income_3/16+$income_4/16+$income_5/16+$income_6/16+$income_7/16+$income_8/16;

//** Level up character
$player_level_1 = $row['level'];
$player_experience_1 = $row['experience']+$total_exp_claim;

$g_level_up = $mysqli->query("SELECT * FROM leveling_up WHERE level='".$player_level_1."'");
$level_up = mysqli_fetch_assoc($g_level_up);
$get_level = $level_up['level'];
$get_exp_required = $level_up['exp_required'];

if($player_experience_1 > $get_exp_required){
$player_level_up = $player_level_1+1;
$update_level_up_0 = $mysqli->query("SELECT * FROM leveling_up WHERE level='".$player_level_up."'");
$update_level_up_1 = mysqli_fetch_assoc($update_level_up_0);
$update_level_up = $update_level_up_1['exp_required'];

$exp_to_carry_over = $player_experience_1-$get_exp_required;
$result_4196 = $mysqli->query("UPDATE characters SET claimedbonus='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET cash=cash+'".$total_cash_claim."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4198 = $mysqli->query("UPDATE characters SET level='".$player_level_up."' WHERE id='".$character_id."'");
$result_4199 = $mysqli->query("UPDATE characters SET experience='".$exp_to_carry_over."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));

}elseif($player_experience_1 == $get_exp_required){
$player_level_up = $player_level_1+1;
$update_level_up_0 = $mysqli->query("SELECT * FROM leveling_up WHERE level='".$player_level_up."'");
$update_level_up_1 = mysqli_fetch_assoc($update_level_up_0);
$update_level_up = $update_level_up_1['exp_required'];

$result_4196 = $mysqli->query("UPDATE characters SET claimedbonus='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET cash=cash+'".$total_cash_claim."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4198 = $mysqli->query("UPDATE characters SET level='".$player_level_up."' WHERE id='".$character_id."'");
$result_4199 = $mysqli->query("UPDATE characters SET experience='0' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));

}else{
$result_4196 = $mysqli->query("UPDATE characters SET claimedbonus='".$date_today."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4197 = $mysqli->query("UPDATE characters SET cash=cash+'".$total_cash_claim."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
$result_4199 = $mysqli->query("UPDATE characters SET experience='".$player_experience_1."' WHERE id='".$character_id."'") or die(mysqli_error("Error.."));
}
//** Level up character
?>
{
"status": "Eccellente!",
"message": "You have claimed <?php echo "<font size='3' color='yellow'>$".number_format($total_cash_claim)."</font> and ".number_format($total_exp_claim)." exp "; ?> from your top mob."
}
<?php
}



}
?>