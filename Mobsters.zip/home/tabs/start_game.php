<?php
//** PREVENT BOTS
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if(!IS_AJAX) {
http_response_code(404);
die();
}

session_start();
if(!$_SESSION['user_id'] == null){
$user_id = $_SESSION['user_id'];
if(isset($_GET['name'])){
$name = $_GET['name'];
$class = $_GET['class'];
if($name == '' || $class == '' || $class > '3'){
echo '{
  "status": "Insuccesso:",
  "message": "Please fill in all fields."
}';
}else{
if(strlen($name) > 16) {
echo '{
  "status": "Insuccesso:",
  "message": "Your name is too long."
}';
}else{
if(ctype_alnum($name)){
require '../../conn1651651651651.php';
$result = $mysqli->query("SELECT * FROM characters WHERE charactername='".$name."'");
$count = mysqli_num_rows($result);
if($count > 0){
echo '{
  "status": "Insuccesso:",
  "message": "Sorry, '.$name.' is taken."
}';
}else{
echo '{
"status": "success",
"message": "Welcome, '.$name.'",
"name": "'.$name.'",
"class": "'.$class.'"
}';
$mysqli->query("INSERT INTO characters (belongsto, characterloaded, charactername, class) VALUES('$user_id','1','$name','$class')");

$result = $mysqli->query("SELECT * FROM characters WHERE belongsto='".$user_id."' AND characterloaded='1'");
$count = mysqli_num_rows($result);
if($count > 0){
$y = mysqli_fetch_assoc($result);
$_SESSION['character_id'] = $y['id'];
}

}
}else{
echo '{
  "status": "Insuccesso:",
  "message": "Please remove any special characters."
}';
}

}
}
}
}
?>