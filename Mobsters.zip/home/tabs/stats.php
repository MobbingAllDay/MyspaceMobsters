<?php
//** PREVENT BOTS
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
if(!IS_AJAX) {
http_response_code(404);
die();
}

?>
<b><div style='line-height:1.4;border-bottom: 1px solid white;padding:35px 0px 0px 0px;font-size:25px;color:grey;' align='left'>
<?php
echo "<center><font color='white'>Stats Page</font></center>";
?>
</div></b>