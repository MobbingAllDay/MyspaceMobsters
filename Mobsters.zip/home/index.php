<center><a style='color:white;text-decoration:none;' href='logout.php'>[Logout]</a></center>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
$maintenance = "0";

session_start();
if(!$_SESSION['user_id'] == null){
$user_id = $_SESSION['user_id'];
?>
<title>Mobsters</title>
<body bgcolor='black'>
<?php $load = rand(10000000,999999999); //$load = "0"; ?>
<script src="js/jquery-1.5.1.min.js?update=<?php echo $load; ?>"></script>
<script src="js/jquery.js?update=<?php echo $load; ?>" type="text/javascript"></script>
<link rel="stylesheet" href="css/style.css?update=<?php echo $load; ?>">
<?php
require '../conn1651651651651.php';
if($_SESSION['character_id'] !== ''){
if($maintenance == '1'){
?>
<div class="header"></div>
<div class="main" style="width:100%;">
<table align="center" style="border: solid 1px #505050;background-color:#F1F0F0;color:#404040;height:40;width:370px;">
<tr>
<td style="padding-bottom:3px;padding-top:3px;"><center><font size="4"><b>We're under Maintenance</b><br><font size="4"><b>We will be right back!</b></font></center></td>
</tr>
</table>
<div style="margin-left:auto;margin-right:auto;width:1020px;height:5000px;padding-left:40px;padding-top:35px;">
<div id="main_container">
</div></div></div>
<?php
}
if($maintenance == '0'){
echo '<script>
window.onload = function() {
load_game();
}
</script>';
?>

<div id='header' class="header"></div>

<div class="main" style='width:100%;'>
<table id="loading" align="center" style="border:solid 1px #505050;background-color:#F1F0F0;color:#404040;position:relative;height:40;width:370px;">
<tr>
<td style="padding-bottom:3px;padding-top:3px;"><center><font size="4"><b>Loading your info...</b></font><br><font size="1"><b>(Please do not refresh unless this takes more than 30 seconds)</b></font></center></td>
</tr>
</table>
<table id='loadtabs' align='center' style='display:none;padding-left:30px;position:relative;top:0;width:1050px;'><tr><td>
<div id='main' class='nav_selected'>Main</div>	
<div id='missions' class='top-nav'>Missions</div>
<div id='territory' class='top-nav'>Territory</div>	
<div id='bank' class='top-nav'>Bank</div>
<div id='godfather' class='top-nav'>Godfather</div>
<div id='fight' class='top-nav'>Attack</div>
<div id='hitlist' class='top-nav'>Hit List</div>	
<div id='equipment' class='top-nav'>Equipment</div>
<div id='hospital' class='top-nav'>Hospital</div>										
<div id='mymob' class='top-nav'>My Mob</div>
<div id='mymobster' class='top-nav'>My Mobster</div>
<div id='mademen' class='top-nav'>Made Men</div>
<div id='help' class='top-nav'>Help</div>
</td></tr></table>
<?php
echo "<table style='padding-left:10px;width:990;' align='center'><tr><td><div id='status' style='position:relative;top:40;width:100%;'></div></td></tr></table>";
?>
<div style="margin-left:auto;margin-right:auto;width:1020px;height:5000px;padding-left:40px;padding-top:35px;">
<div id="main_container"></div>
</div></div>

<?php
}
}else{
?>
<div id='welcome' class="welcome"></div>
<table style='width:990px;' align='center'><tr><td><div style='width:100%;' id="error_debug"></div></td></tr></table>
<form id="npform" onsubmit="setTimeout(function(){try{mobsterconfirm();}catch(e){}},250);return false;" >
<table style='width:900px;' align='center' border='0'><tr><td>
						<div style="font-size:24px;color:white;max-width:100%;border-bottom: 1px solid white;">Pick a Name</div>
						<div style='padding-top:10px;'><input type = "text" id = "mobName"  aoninput="this.value = this.value.replace(/[^A-Za-z0-9 ]/g, ''); " name = "mobName" placeholder = "Type Name Here" autocomplete='off' /><b><font color='grey'> Please be tasteful</font></b></div> 
						<br>
						<div style="font-size:24px;color:white;max-width:100%;border-bottom: 1px solid white;">Pick a Specialty</div>
</td></tr></table>

<table align='center' border='0'><tr><td>

<table id="0" align='left' style='border: 1px solid #585A5C;color:white;'>
<tr>
<td style='border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;'><input type="radio" id="special" name="special" onclick="chooseclass();" value="0"> <b>Nightowl</b></td>
</tr>
<tr>
<td><img src="images/js0.png" width="210" height="200"></td>
</tr>
<tr>
<td style='padding-bottom:47px;'><center><font size='4' color='#585A5C'>Regains energy<br>faster. You'll need<br>energy to do missions.</font></center></td>
</tr>
</table>

<table id="1" align='left' style='border: 1px solid #585A5C;color:white;'>
<tr>
<td style='border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;'><input type="radio" id="special" name="special" onclick="chooseclass();" value="1"> <b>Soldato</b></td>
</tr>
<tr>
<td><img src="images/js1.png" width="210" height="200"></td>
</tr>
<tr>
<td style='padding-bottom:25px;'><center><font size='4' color='#585A5C'>Regains health faster.<br>Health is important<br>when fighting against<br>enemy mobsters.</font></center></td>
</tr>
</table>

<table id="2" align='left' style='border: 1px solid #585A5C;color:white;'>
<tr>
<td style='border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;'><input type="radio" id="special" name="special" onclick="chooseclass();" value="2"> <b>Mogul</b></td>
</tr>
<tr>
<td><img src="images/js2.png" width="210" height="200"></td>
</tr>
<tr>
<td style='padding-bottom:25px;'><center><font size='4' color='#585A5C'>Your territories pay<br>income more often,<br>giving you more $$$<br>for good equipment.</font></center></td>
</tr>
</table>

<table id="3" align='left' style='border: 1px solid #585A5C;color:white;'>
<tr>
<td style='border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;'><input type="radio" id="special" name="special" onclick="chooseclass();" value="3"> <b>Renegade</b></td>
</tr>
<tr>
<td><img src="images/js3.png" width="210" height="200"></td>
</tr>
<tr>
<td style='padding-bottom:3px;'><center><font size='4' color='#585A5C'>This "jack of all<br>trades" gets smaller<br>bonuses, But to<br>everything! Health,<br>Energy and $$$</font></center></td>
</tr>
</table>

</td></tr></table>

<table style='padding-top:10px;' align='center' border='0'><tr><td>
<div class="buttonDiv" style="font-size:14px; "><a class="button button_blue" onclick="$('#npform').submit();"><span style="font-size:14px;">Continue</span></a></div></form>
</td></tr></table>
<?php
}
}else{
header('Location: ../../');
exit;
}
?>