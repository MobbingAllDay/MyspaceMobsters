var CANVAS_REF = "keep-alive";
var iFold=0;
var tabs = "http://localhost/home/tabs/";
var images = "http://localhost/home/images/";

//** Start game
function chooseclass(){
var $questions = $('special'), $answers = $(':checked');
var selected = $($answers).val();

var x = document.getElementById(selected).getElementsByTagName("td");
x[0].style.backgroundColor = "#75190A";

if(selected === '0'){
document.getElementById('1').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
document.getElementById('2').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
document.getElementById('3').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
}
if(selected === '1'){
document.getElementById('0').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
document.getElementById('2').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
document.getElementById('3').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
}
if(selected === '2'){
document.getElementById('0').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
document.getElementById('1').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
document.getElementById('3').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
}
if(selected === '3'){
document.getElementById('0').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
document.getElementById('1').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
document.getElementById('2').getElementsByTagName("td")[0].style = "border-bottom: 1px solid #585A5C;color:white;padding-left:60px;padding-right:60px;";
}

}
function mobsterconfirm(){
var $questions = $('special'), $answers = $(':checked');
var selected = $($answers).val();
if(selected == null){
}else{
var t=$("#mobName").val();
$.ajax({type:"GET",url:tabs+"start_game.php?name="+t+"&class="+selected,data:{},dataType:"json",cache:false,success:function(e){
var t=e.status;
var n=e.message;
if(t=="Insuccesso:"){
$("#error_debug").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:17px;'>"+n+"</p></div></div>");
return;
}
setTimeout(function(){window.location="../../home/"},0)}});
}
}
// End of start game


//** Stats Page
function my_stats(){
$("#status").html("");
$('.nav_selected').each(function() {
$(this).attr("class","top-nav");
});
$('#header').load(tabs+'header.php');
$('#main_container').load(tabs+'stats.php');
}
function mymobsterstabb(){
$('.nav_selected').each(function() {
$(this).attr("class","top-nav");
});
$('#mymobster').attr("class","nav_selected");
$("#status").html("");
$('#header').load(tabs+'header.php');
$('#main_container').load(tabs+'mymobster.php');
}

//** Send Energy
function send_energy(id){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><div style='padding:20px 0px 18px 20px;color:white;font-size:17px;'>Sending Energy...</div></div>");

setTimeout(function(){
var m=id;
$.ajax({type:"GET",url:tabs+"send_energy.php?id="+m,data:{},dataType:"json",cache:false,success:function(e){
var t=e.status;
var n=e.message;
if(t=="Insuccesso:"){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
return;
}
if(t=="Eccellente!"){
$(document).ready(function(){
$('#header').load(tabs+'header.php');
$('#main_container').load(tabs+'main.php');
});
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
}

}});
}, 150);
}

//** Claim Bonus
function claim_bonus(){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><div style='padding:20px 0px 18px 20px;color:white;font-size:17px;'>Claiming Bonus...</div></div>");

setTimeout(function(){
$.ajax({type:"GET",url:tabs+"claim_bonus.php",data:{},dataType:"json",cache:false,success:function(e){
var t=e.status;
var n=e.message;
var x=e.gained_experience;
if(t=="Insuccesso:"){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
return;
}
if(t=="Eccellente!"){
$(document).ready(function(){
$('#header').load(tabs+'header.php');
$('#main_container').load(tabs+'main.php');
});
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
}

}});
}, 150);
}

//** Mission Tab
function do_mission(id){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><div style='padding:20px 0px 18px 20px;color:white;font-size:17px;'>Doing mission...</div></div>");

setTimeout(function(){
var m=id;
$.ajax({type:"GET",url:tabs+"missions.php?mission="+m,data:{},dataType:"json",cache:false,success:function(e){
var t=e.status;
var n=e.message;
var d=e.id;
var u=e.used_energy;
var x=e.gained_experience;
var c=e.gained_cash;
var wn=e.weapon_name;
var wp=e.weapon_picture;
var hm=e.weapon_how_many;
var level_up=e.level_up;
var addquotes = '"';
if(t=="Insuccesso:"){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
return;
}
if(t=="Eccellente!"){
$(document).ready(function(){
$('#header').load(tabs+'header.php');
$('#main_container').load(tabs+'missions.php');
});
if(c==""){
if(wn > ""){
if(level_up > ""){
$("#status").html("<div style='-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none; unselectable:on;onselectstart:return false;onmousedown:return false; padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:0px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><div style='padding-left:15px;position:relative;bottom:50px;padding-right:25px;display: inline-block;'><img src='"+wp+"'></div><div style='position:relative;bottom:0px;right:46px;display: inline-block;'><div style='padding:0px 0px 20px 20px;color:white;font-size:15px;'><b>Congratulations!</b> You have reached <a onclick='mymobsterstabb();' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>level "+level_up+"</a></div><div style='padding:0px 0px 5px 20px;color:white;font-size:15px;'>"+addquotes+""+n+""+addquotes+"</div><div style='padding:0px 0px 5px 24px;color:white;font-size:15px;'>You used <b><font size='3' color='red'>"+u+"</font></b> energy to complete the mission.<br>You gained <b><font size='3' color='orange'>"+x+"</font></b> experience.<br>You gained <b><font size='3' color='white'>"+hm+" </font></b>"+wn+".</div><div style='padding:30px 0px 15px 24px;color:white;font-size:15px;'><a id='"+d+"' onclick='do_mission(this.id);' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>Do this mission again!</a></div></div></div></div>");
}else{
$("#status").html("<div style='-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none; unselectable:on;onselectstart:return false;onmousedown:return false; padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:0px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><div style='padding-left:15px;position:relative;bottom:50px;padding-right:25px;display: inline-block;'><img src='"+wp+"'></div><div style='position:relative;bottom:0px;right:46px;display: inline-block;'><div style='padding:0px 0px 5px 20px;color:white;font-size:15px;'>"+addquotes+""+n+""+addquotes+"</div><div style='padding:0px 0px 5px 24px;color:white;font-size:15px;'>You used <b><font size='3' color='red'>"+u+"</font></b> energy to complete the mission.<br>You gained <b><font size='3' color='orange'>"+x+"</font></b> experience.<br>You gained <b><font size='3' color='white'>"+hm+" </font></b>"+wn+".</div><div style='padding:30px 0px 15px 24px;color:white;font-size:15px;'><a id='"+d+"' onclick='do_mission(this.id);' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>Do this mission again!</a></div></div></div></div>");
}
}else{
if(level_up > ""){
$("#status").html("<div style='-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none; unselectable:on;onselectstart:return false;onmousedown:return false; padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:0px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><div style='padding:0px 0px 7px 40px;color:white;font-size:15px;'><b>Congratulations!</b> You have reached <a onclick='mymobsterstabb();' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>level "+level_up+"</a></div><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+addquotes+""+n+""+addquotes+"</p><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>You used <b><font size='3' color='red'>"+u+"</font></b> energy to complete the mission.<br>You gained <b><font size='3' color='orange'>"+x+"</font></b> experience.</p><p style='padding:20px 0px 0px 40px;color:white;font-size:15px;'><a id='"+d+"' onclick='do_mission(this.id);' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>Do this mission again!</a></p></div></div>");
}else{
$("#status").html("<div style='-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none; unselectable:on;onselectstart:return false;onmousedown:return false; padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:0px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+addquotes+""+n+""+addquotes+"</p><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>You used <b><font size='3' color='red'>"+u+"</font></b> energy to complete the mission.<br>You gained <b><font size='3' color='orange'>"+x+"</font></b> experience.</p><p style='padding:20px 0px 0px 40px;color:white;font-size:15px;'><a id='"+d+"' onclick='do_mission(this.id);' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>Do this mission again!</a></p></div></div>");
}
}
}



if(c > ""){
if(wn > ""){
if(level_up > ""){
$("#status").html("<div style='-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none; unselectable:on;onselectstart:return false;onmousedown:return false; padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:0px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><div style='padding-left:15px;position:relative;bottom:50px;padding-right:25px;display: inline-block;'><img src='"+wp+"'></div><div style='position:relative;bottom:0px;right:46px;display: inline-block;'><div style='padding:0px 0px 20px 20px;color:white;font-size:15px;'><b>Congratulations!</b> You have reached <a onclick='mymobsterstabb();' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>level "+level_up+"</a></div><div style='padding:0px 0px 20px 20px;color:white;font-size:15px;'>"+addquotes+""+n+""+addquotes+"</div><div style='padding:0px 0px 5px 24px;color:white;font-size:15px;'>You used <b><font size='3' color='red'>"+u+"</font></b> energy to complete the mission.<br>You gained <b><font size='3' color='yellow'>"+c+"</font></b> and <b><font size='3' color='orange'>"+x+"</font></b> experience.<br>You gained <b><font size='3' color='white'>"+hm+" </font></b>"+wn+".</div><div style='padding:30px 0px 15px 24px;color:white;font-size:15px;'><a id='"+d+"' onclick='do_mission(this.id);' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>Do this mission again!</a></div></div></div></div>");
}else{
$("#status").html("<div style='-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none; unselectable:on;onselectstart:return false;onmousedown:return false; padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:0px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><div style='padding-left:15px;position:relative;bottom:50px;padding-right:25px;display: inline-block;'><img src='"+wp+"'></div><div style='position:relative;bottom:0px;right:46px;display: inline-block;'><div style='padding:0px 0px 20px 20px;color:white;font-size:15px;'>"+addquotes+""+n+""+addquotes+"</div><div style='padding:0px 0px 5px 24px;color:white;font-size:15px;'>You used <b><font size='3' color='red'>"+u+"</font></b> energy to complete the mission.<br>You gained <b><font size='3' color='yellow'>"+c+"</font></b> and <b><font size='3' color='orange'>"+x+"</font></b> experience.<br>You gained <b><font size='3' color='white'>"+hm+" </font></b>"+wn+".</div><div style='padding:30px 0px 15px 24px;color:white;font-size:15px;'><a id='"+d+"' onclick='do_mission(this.id);' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>Do this mission again!</a></div></div></div></div>");
}
}else{
if(level_up > ""){
$("#status").html("<div style='-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none; unselectable:on;onselectstart:return false;onmousedown:return false; padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:0px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><div style='padding:0px 0px 7px 40px;color:white;font-size:15px;'><b>Congratulations!</b> You have reached <a onclick='mymobsterstabb();' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>level "+level_up+"</a></div><p style='padding:0px 0px 5px 35px;color:white;font-size:15px;'>"+addquotes+""+n+""+addquotes+"</p><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>You used <b><font size='3' color='red'>"+u+"</font></b> energy to complete the mission.<br>You gained <b><font size='3' color='yellow'>"+c+"</font></b> and <b><font size='3' color='orange'>"+x+"</font></b> experience.</p><p style='padding:20px 0px 0px 40px;color:white;font-size:15px;'><a id='"+d+"' onclick='do_mission(this.id);' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>Do this mission again!</a></p></div></div>");
}else{
$("#status").html("<div style='-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none; unselectable:on;onselectstart:return false;onmousedown:return false; padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:0px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 35px;color:white;font-size:15px;'>"+addquotes+""+n+""+addquotes+"</p><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>You used <b><font size='3' color='red'>"+u+"</font></b> energy to complete the mission.<br>You gained <b><font size='3' color='yellow'>"+c+"</font></b> and <b><font size='3' color='orange'>"+x+"</font></b> experience.</p><p style='padding:20px 0px 0px 40px;color:white;font-size:15px;'><a id='"+d+"' onclick='do_mission(this.id);' style='font-size:16px;color:#2E65E3;text-decoration:underline;cursor:pointer;'>Do this mission again!</a></p></div></div>");
}
}
}

}
}});
}, 150);
}




//** Bank Tab
function withdrawform(){
var l=$("#withdrawcash").val();
$.ajax({type:"GET",url:tabs+"bank.php?deposit=withdraw&cash="+l,data:{},dataType:"json",cache:false,success:function(e){
var t=e.status;
var n=e.message;
if(t=="Insuccesso:"){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
return;
}
if(t=="Eccellente!"){
$(document).ready(function(){
$('#header').load(tabs+'header.php');
$('#main_container').load(tabs+'bank.php');
});
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
}
}});
}

function depositform(){
var l=$("#depositcash").val();
$.ajax({type:"GET",url:tabs+"bank.php?deposit=deposit&cash="+l,data:{},dataType:"json",cache:false,success:function(e){
var t=e.status;
var n=e.message;
if(t=="Insuccesso:"){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
return;
}
if(t=="Eccellente!"){
$(document).ready(function(){
$('#header').load(tabs+'header.php');
$('#main_container').load(tabs+'bank.php');
});
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
}
}});
}
//** End of Bank Tab





//** Godfather Tab
function acceptcash(){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><div style='padding:20px 0px 20px 20px;color:white;font-size:17px;'>Accepting reward...</div></div></div>");

setTimeout(function(){
$.ajax({type:"GET",url:tabs+"godfather.php?accept=cash",data:{},dataType:"json",cache:false,success:function(e){
var t=e.status;
var n=e.message;
if(t=="Insuccesso:"){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
return;
}
if(t=="Eccellente!"){
$(document).ready(function(){
$('#header').load(tabs+'header.php');
$('#main_container').load(tabs+'godfather.php');
});
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
}
}});
}, 150);
}

function accepthiredgun(){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><div style='padding:20px 0px 20px 20px;color:white;font-size:17px;'>Accepting reward...</div></div></div>");

setTimeout(function(){
$.ajax({type:"GET",url:tabs+"godfather.php?accept=hiredgun",data:{},dataType:"json",cache:false,success:function(e){
var t=e.status;
var n=e.message;
if(t=="Insuccesso:"){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
return;
}
if(t=="Eccellente!"){
$(document).ready(function(){
$('#header').load(tabs+'header.php');
$('#main_container').load(tabs+'godfather.php');
});
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
}
}});
}, 150);
}

function acceptrefill(){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><div style='padding:20px 0px 20px 20px;color:white;font-size:17px;'>Accepting reward...</div></div></div>");

setTimeout(function(){
var r=$("#refill").val();
$.ajax({type:"GET",url:tabs+"godfather.php?accept=refill&refill="+r,data:{},dataType:"json",cache:false,success:function(e){
var t=e.status;
var n=e.message;
if(t=="Insuccesso:"){
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
return;
}
if(t=="Eccellente!"){
$(document).ready(function(){
$('#header').load(tabs+'header.php');
$('#main_container').load(tabs+'godfather.php');
});
$("#status").html("<div style='padding:0px 0px 15px 0px;font-family: Helvetica;'><div style='color: #FF0000; border: 1px solid white;'><h2 style='padding:5px 0px 0px 20px;color:orange;font-size:15px;'>"+t+"</h2><p style='padding:0px 0px 5px 40px;color:white;font-size:15px;'>"+n+"</p></div></div>");
}
}});
}, 150);
}
//** End of Godfather Tab

//** Timer Refresh
function timerrefresh()
{
$('#header').load(tabs+'header.php');
}


//** Refresh button
function refresh() // no ';' here
{
    var elem = document.getElementById("refresh_button");
    if (elem.value=="REFRESH") {
	elem.value = "Refreshing...";
	document.getElementById('refresh_button').style.cssText = 'cursor:pointer;padding:4px 12px 4px 12px;border-color:grey;border-style:solid;color:white;font-size:12px;background-color:grey;';
	setTimeout(function(){
    elem.value = "REFRESH";
	document.getElementById('refresh_button').style.cssText = 'cursor:pointer;padding:4px 18px 4px 18px;border-width: 1px;color:white;font-size:12px;border: solid 1px #555555;background-color: #2F2F4F;';
	
	$('.nav_selected').each(function() {
    var id = this.id;
	if(id == 'main'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'main.php');
	}
	if(id == 'missions'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'missions.php');
	}
	if(id == 'territory'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'territory.php');
	}
	if(id == 'bank'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'bank.php');
	}
	if(id == 'godfather'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'godfather.php');
	}
	if(id == 'fight'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'fight.php');
	}
	if(id == 'hitlist'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'hitlist.php');
	}
	if(id == 'equipment'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'equipment.php');
	}
	if(id == 'hospital'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'hospital.php');
	}
	if(id == 'mymob'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'mymob.php');
	}
	if(id == 'mymobster'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'mymobster.php');
	}
	if(id == 'mademen'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'made_men.php');
	}
	if(id == 'help'){
	$("#status").html("");
	$('#header').load(tabs+'header.php');
    $('#main_container').load(tabs+'help.php');
	}
    });
	
	}, 200);
	}
}
//** End of refresh button


function load_game() {
setTimeout(function(){
var header = $('#header').load(tabs+'header.php');
var container = $('#main_container').load(tabs+'main.php');
document.getElementById('loading').innerHTML = "padding-left:30px;position:relative;top:35;width:1050px;";
document.getElementById('loading').style = "display:none;";
document.getElementById('loadtabs').style = "padding-left:30px;position:relative;top:35;width:1050px;";
}, 400);
}

function da_bronx_click() {
$('#main_container').load(tabs+'missions.php?city_name=da_bronx');
$(".da_bronx").attr("class","da_bronx_red");
$("#downtown").attr("class","downtown");
$("#jersey").attr("class","jersey");
$("#outta_town").attr("class","outta_town");
}
function downtown_click() {
$('#main_container').load(tabs+'missions.php?city_name=downtown');
$("#da_bronx").attr("class","da_bronx");
$(".downtown").attr("class","downtown_red");
$("#jersey").attr("class","jersey");
$("#outta_town").attr("class","outta_town");
}
function jersey_click() {
$('#main_container').load(tabs+'missions.php?city_name=jersey');
$("#da_bronx").attr("class","da_bronx");
$("#downtown").attr("class","downtown");
$(".jersey").attr("class","jersey_red");
$("#outta_town").attr("class","outta_town");
}
function outta_town_click() {
$('#main_container').load(tabs+'missions.php?city_name=outta_town');
$("#da_bronx").attr("class","da_bronx");
$("#downtown").attr("class","downtown");
$("#jersey").attr("class","jersey");
$(".outta_town").attr("class","outta_town_red");
}

$(document).ready(function(){
		
	   $("#main").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'main.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#missions").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'missions.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#territory").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'territory.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#bank").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'bank.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#godfather").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'godfather.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#fight").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'fight.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#hitlist").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'hitlist.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#equipment").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'equipment.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#hospital").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'hospital.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#mymob").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'mymob.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#mymobster").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'mymobster.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#mademen").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'made_men.php');
		$(this).attr("class","nav_selected");
       });
	   
	   $("#help").click(function(){
		$('.nav_selected').each(function() {
        $(this).attr("class","top-nav");
        });
		$("#status").html("");
        $('#main_container').load(tabs+'help.php');
		$(this).attr("class","nav_selected");
       });
	   
     });